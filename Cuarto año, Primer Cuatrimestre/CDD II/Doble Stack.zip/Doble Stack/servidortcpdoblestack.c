/* Servidor eco TCP 
Escucha en el port 8001
El servidor atiende varias clientes simultaneamente.
Esta preparado para IPv6, y en una maquina con doble stack puede atender requerimientos de clientes IPv4
ya que el host doble stack provee mapped addresses
*/


#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <arpa/inet.h>

int main(int argc, char**argv)
{
   //Descriptor del socket donde el servidor acepta requerimientos de conexion
   int listenfd;
   //Descriptor del socket donde el (cada uno) proceso hijo atiende la conexion
   int connfd;
   //String para almacenar direccion del servidor
   char strserver [INET6_ADDRSTRLEN];
   //String para almacenar la direccion de cada proceso hijo del servidor
   char strchild [INET6_ADDRSTRLEN];
   //String para almacenar la direccion de cada cliente
   char strclient [INET6_ADDRSTRLEN];
   int n;
   //Estructura que describe la direccion del servidor
   struct sockaddr_in6 servaddr;
   //Estructura que describe la direccion del cliente
   struct sockaddr_in6 cliaddr;
   socklen_t clilen;
   //Almacena el numero de proceso del proceso hijo (fork)
   pid_t     childpid;
   //Buffer para almacenar el mensaje recibido   
   char mesg[1000];
   //Pedimos al sistema un socket de la familia AF_INET6, tipo stream, con protocolo por defecto (TCP)
   //Por error, terminamos 
   if( (listenfd=socket(AF_INET6,SOCK_STREAM,0)) == -1) {
     perror("Error a solicitar socket"); 
     exit(-1);
   }
   //Preparamos la direccion del servidor en la estructura sockaddr_in6:
   //todo en cero
   bzero(&servaddr,sizeof(servaddr));
   //Familia de direcciones (stack tcp/ip -version 6-)
   servaddr.sin6_family = AF_INET6;
   //Si se paso la direccion del servidor como argumento, la usamos
   //if (argc == 2)  
   //   inet_pton(AF_INET6, argv[1], &(servaddr.sin6_addr));
   //  else  
   //   servaddr.sin6_addr   = in6addr_any;
   servaddr.sin6_addr   = in6addr_any;
   //Port fijo, 8001
   servaddr.sin6_port=htons(8001);
   //Asociamos el socket con la direccion ip y el port
    if( bind(listenfd,(struct sockaddr *)&servaddr,sizeof(servaddr)) == -1) {
      perror("Error en bind");
      exit(-1);
   }   

   //Indica que se puede tener en el socket hasta 5 requerimientos de conexion pendientes
   if(listen(listenfd,5)==-1) perror("listen ");
 
   inet_ntop(AF_INET6, &(servaddr.sin6_addr), strserver, INET6_ADDRSTRLEN);
   printf("\n****Servidor esperando reqs de conexion en ip: %s  port: %d\n", strserver, ntohs(servaddr.sin6_port)); 
   for(;;)
   {
      clilen=sizeof(cliaddr);
     //Al salir del accept, retorna con un nuevo req de conexion
      connfd = accept(listenfd,(struct sockaddr *)&cliaddr,&clilen);
      inet_ntop(AF_INET6, &(cliaddr.sin6_addr), strclient, INET6_ADDRSTRLEN); 
      printf("\n\n****Servidor recibe req. de conexion de ip: %s  port: %d\n", strclient, ntohs(cliaddr.sin6_port)); 
      if ((childpid = fork()) == 0)
      {
         struct sockaddr_in6 childaddr;
         socklen_t  childlen;
         childlen = sizeof(childaddr);
         getsockname(connfd, (struct sockaddr *) &childaddr, &childlen);
         inet_ntop(AF_INET6,  &(childaddr.sin6_addr), strchild, INET6_ADDRSTRLEN); 
         printf("Proc. hijo %d (ip %s, port %d)<--conectado con-->(ip %s, port %d) \n",
                       getpid(), strchild, ntohs(childaddr.sin6_port), strclient, ntohs(cliaddr.sin6_port));
         //Como es el proceso hijo, cierra el socket desde donde se aceptan conexiones
         close (listenfd);
         //Hasta finalizar, recibe datos del cliente y hace el eco
         for(;;)
         {
            //Lee del socket
            n = recvfrom(connfd,mesg,1000,0,(struct sockaddr *)&cliaddr,&clilen);
             //Si no recibio, reintenta
            if(n==0) continue;
            //Si recibio datos, los muestra y hace el eco.
            sendto(connfd,mesg,n,0,(struct sockaddr *)&cliaddr,sizeof(cliaddr));
            mesg[n] = 0;
            printf("--------------------------------------------------------------------------------\n");
            printf("Proc %d: recibe :%s\n",getpid(), mesg);
          }
      }
      //Como es el proceso padre, cierra el socket de atencion al cliente
      close(connfd);
      printf("\n****Servidor continua esperando requerimientos de conexion");
   }
}
