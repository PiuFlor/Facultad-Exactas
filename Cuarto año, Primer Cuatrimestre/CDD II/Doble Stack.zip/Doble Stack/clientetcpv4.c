/* Sample TCP client */

#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char**argv)
{
   //Descriptor del socket
   int sockfd;
   int n;
   //Estructura que describe la direccion del servidor
   struct sockaddr_in servaddr;
   //Estructura que describe la direccion del cliente
   struct sockaddr_in cliaddr;
   //Buffer para lectura de mensaje a enviar
   char sendline[1000];
   //Buffer para lectura del eco 
   char recvline[1000];
  //Es necesario especificar la direccion del servidor
   if (argc != 2)
   {
      printf("%s.  Uso: dir_IP_server addr\n", argv[0]);
      exit(1);
   }
   //Descriptor del socket
   sockfd=socket(AF_INET,SOCK_STREAM,0);
   //Ponemos en cero la direccion del servidor
   bzero(&servaddr,sizeof(servaddr));
   //Especificamos la direccion del servidor
   //Flia AF_INET (stack tcp/ip)
   servaddr.sin_family = AF_INET;
   //Direccion IP dada como parametro
   servaddr.sin_addr.s_addr=inet_addr(argv[1]);
   //Port fijo 8000
   servaddr.sin_port=htons(8001);
   //Solicitamos a TCP que establezca una conexion con el lado remoto
   connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
   //Mientras se ingresen mensajes, enviarlos . . .
   while (fgets(sendline, 10000,stdin) != NULL)
   {
      sendto(sockfd,sendline,strlen(sendline),0, (struct sockaddr *)&servaddr,sizeof(servaddr));
      n=recvfrom(sockfd,recvline,10000,0,NULL,NULL);
      recvline[n]=0;
      fputs(recvline,stdout);
   }
}
