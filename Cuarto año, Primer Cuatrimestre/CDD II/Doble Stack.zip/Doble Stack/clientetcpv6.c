/* Sample TCP client */

#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char**argv)
{
   //Descriptor del socket
   int sockfd;
   int n;
   //Estructura que describe la direccion del servidor
   struct sockaddr_in6 servaddr;
   //Estructura que describe la direccion del cliente
   struct sockaddr_in6 cliaddr;
   //Buffer para lectura de mensaje a enviar
   char sendline[1000];
   //Buffer para lectura del eco 
   char recvline[1000];
  //Es necesario especificar la direccion del servidor
   if (argc != 2)
   {
      printf("%s.  Uso: dir_IP_server addr\n", argv[0]);
      exit(1);
   }
   //Descriptor del socket
   sockfd=socket(AF_INET6,SOCK_STREAM,0);
   //Ponemos en cero la direccion del servidor
   bzero(&servaddr,sizeof(servaddr));
   //Especificamos la direccion del servidor
   //Flia AF_INET (stack tcp/ip)
   servaddr.sin6_family = AF_INET6;
   //Direccion IP dada como parametro
   inet_pton(AF_INET6, argv[1], &(servaddr.sin6_addr));
   //Port fijo 8000
   servaddr.sin6_port=htons(8001);
   //Solicitamos a TCP que establezca una conexion con el lado remoto
   connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
   //Mientras se ingresen mensajes, enviarlos . . .
   while (fgets(sendline, 10000,stdin) != NULL)
   {
      sendto(sockfd,sendline,strlen(sendline),0, (struct sockaddr *)&servaddr,sizeof(servaddr));
      n=recvfrom(sockfd,recvline,10000,0,NULL,NULL);
      recvline[n]=0;
      fputs(recvline,stdout);
   }
}
